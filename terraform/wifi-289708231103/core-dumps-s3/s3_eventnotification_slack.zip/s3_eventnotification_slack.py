import urllib
import json
import boto3
import os

s3 = boto3.client('s3')
slack_webhook_url = os.environ.get('SLACK_WEBHOOK_URL')

def lambda_handler(event, context):
    # Get the bucket and key name from the event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    payload = {"text": f"A new core file *{key}* was uploaded to the "
                        "*openwifi-core-dumps* S3 bucket.\n Please download the "
                        "file and investigate the issue.",
               "username": "core-dump-notifier",
               "icon_emoji": ":desktop_computer:"}
    data = json.dumps(payload).encode()
    headers = {"Content-type": "application/json"}
    req = urllib.request.Request(slack_webhook_url, data, headers)
    with urllib.request.urlopen(req) as response:
        try:
            resp = response.read()
            return resp
        except Exception as e:
            print(e)
            print('Error sending Slack message.')
            raise e
